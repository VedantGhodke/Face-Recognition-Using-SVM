# Face-recognition-using-SVM
It is simple face classification using the Oliviet face dataset and Support Vector Machine.
I have trained SVM classifier to classify the faces. The dataset is Oliviet face dataset that can be imported in scikit learrn.
After training the model can recognise faces with aroung 99% accuracy. It is written in jupyter notebook. 
